# Twitter-clone-project
It is a project based on twitter clone
[Live deployment](https://twitter-clone-shivangi.herokuapp.com/)
