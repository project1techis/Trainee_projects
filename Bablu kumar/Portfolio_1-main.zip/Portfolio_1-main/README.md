# Portfolio_Bablu
This is my Porfolio
This Portfolio is a small project using HTML / CSS and Bootstrap. I will be using this to showmy projects!
[Live Heroku Deployment](https://bablu-portfolio.herokuapp.com/)
Screenshot:![Screenshot 2022-07-22 at 9 56 26 AM](https://user-images.githubusercontent.com/109030441/180362620-8572a3aa-46cf-4ae7-a323-dcab16e8503b.png)

## Technologies Used
* HTML
* CSS
## Installation
No need to install any software, just open up index.html
## How to use ?
Use this template to build your own portfolio
