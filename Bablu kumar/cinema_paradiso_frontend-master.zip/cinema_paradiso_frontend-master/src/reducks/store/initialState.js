const initialState = {
    posts: {
        results: [],
        count: 0,
        next: null,
        previous: null
    },
    favourites: {
        list: []
    },
    movies: {
        results: [],
        count: 0,
        next: null,
        previous: null
    }
};

export default initialState;
