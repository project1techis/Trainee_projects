const initialState = {
  posts: {
    list: [],
  },
  images: {
    list: [],
    hasNext: true,
  },
  favourites: {
    list: [],
  },
  tags: {
    list: [],
  },
};

export default initialState;
