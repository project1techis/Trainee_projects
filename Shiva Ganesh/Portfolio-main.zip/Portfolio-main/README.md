# Portfolio
 Learn about HTML / CSS / Bootstap through creation. Also, when they are looking for a job, customize it to create your own portfolio.
[Visit Demo Website Hosted by Heroku](https://portfolio-shivaganesh.herokuapp.com/)
## Tech used
* HTML
* CSS
## Installation
No need to install anything, just open index.html.
## How to use?
Customize and create your own original portfolio. Take on various challenges such as changing colors, adding effects, and changing designs. Just include ABOUT, PROJECTS, and CONTACT information in your portfolio and don't get too complicated. Simple is the best.
