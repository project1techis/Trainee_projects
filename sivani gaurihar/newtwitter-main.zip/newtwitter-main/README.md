# Twitter-Clone
A sample web page of twitter.
Let's make simple Twitter. Users can post tweets and see everyone's post.
To make the project simple, we do not have a sign in/login function.
So there are no user accounts and follow function.
Check out [LIVE DEMO here!!](https://newtwitter.gshivani.repl.co/)

# Screenshot
![Screenshot 2022-09-22 at 2 40 28 PM](https://user-images.githubusercontent.com/99715140/191707190-753f1a57-6a88-4608-9da9-5f3e61092653.png)

# Tech used
* Html
* Css
* Javascript / JQuery
* Django
* Cloudinary (To host uploaded images on CDN)

# User Story
* Users can post tweets.
* Users can edit tweets.
* Users can delete tweets.
* Users can send a like to a tweet.
