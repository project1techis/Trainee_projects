const initialState = { 
    posts: {
        list: []
    },
    items: {
        list: [],
        price: '',
    },
    carts: {
        list: [],
        subtotal: 0
    }
};

export default initialState