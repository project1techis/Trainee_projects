# Fraudulent_prediction
DATASET link : https://drive.google.com/file/d/1jYtyMgQ47vqnUmaF0SWsjKYmopyHYPRF/view?usp=sharing


1. Predicting wheather job profile is real or fake
