# Seoul-Bike_Linear-Regression


Seoul Bike Dataset  

project summary,

Trip duration, predicting the trip-time precisely for the advancement of

Intelligent Trnasport systems(ITS)

Project to predict the trip duration of rental bikes in Seoul Bike sharing.

The prediction is carried out with the combination of Seoul Bike and weather data.

Features :

Date
1. Rented Bike Count
2. Hour
3. Temperature
4. Humidity(%)
5. Wind Speed(m/s)
6. Visibility(10m)
7. Dew point temperature(C)
8. Solar Radiation(MJ/m2)
9. Rainfall(mm)
10. Snowfall(cm)
