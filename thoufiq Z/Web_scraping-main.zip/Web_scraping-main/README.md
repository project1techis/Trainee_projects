# Web_scraping

## Scraping World’s Top 100 Athletes Using Python
- Scraped top 100 Women athlete for the year 2018 & 2017 from worldathletics.org using Requests & BeautifulSoup4
- Athlete details like : Name ,Age ,City ,Rank etc..was scraped.
- Built a python function so that after passing the particular  year, data will be collected and  will be stored in pandas DataFrame.
- Once the data stored in DataFrame converted the data and saved into CSV file
