from django.contrib import admin
from .models import Places
# Register your models here.
admin.site.register(Places)
