# Twitter Clone
This is my twitter clone where a user can upload his/her post and can also update, edit, like and delete post.

https://twitter-clone-taufeeq.herokuapp.com/
