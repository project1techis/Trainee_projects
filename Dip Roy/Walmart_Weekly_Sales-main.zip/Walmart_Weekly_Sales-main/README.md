# Walmart_Weekly_Sales
Import Libraries
load dataset.

Then Analyzing the dataset, using isnull, shape, describe,pivot table.

Then using Pairplot from Seaborn library to understand dataset.

Using box plot checked and removed outliers.

Using jointplot from Seaborn to plot the linear relation between each column.

Ploting corelation. (Heatmap from seaborn)

Normalizing data using Standerd Scaler.

using RFE to check important feature.

Training model with RandomForestRegressor

Tesing model.

Score of Model is: 95%
