# Employee_Attrition_Kaggle
# Title：Predicting Employee Attrition
# Level：Intermediate
# Category：Classification
# Problem Description: 
This is a problem to predict Whether the employees Leave the Company or Not
This dataset is about employee attrition prediction. The data contains 19,104 instances  (employees) with other features such as Age, gender, city, Date of joining, Last working date, Designation etc
Uncovered the factors that lead to employee attrition. Extracted data and done feature aggregation.
This prediction would be useful for Hr analytics and to decrease employee attrition.

If you unzip the zip file, the following csv is included. 
* dataset.csv is the main dataset,
* I have segregated TRAIN DATA - EA_train.csv, 
* TEST DATA- EA_test.csv, 
* PREDICTION DATA-  EA_answer.csv
