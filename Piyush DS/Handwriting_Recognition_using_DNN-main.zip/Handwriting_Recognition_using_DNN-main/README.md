# Handwriting_Recognition_using_DNN
This project will include stable training deep neural network model.<br>

We are going to employ the keras based python deep learning framework that readily offers complex mathematical layers that compute and form weights that are resultant of the data the model is viewing and learning from and then predict on new dataset.<br>

There's a strong connection between the hand and the neural circuitry of the brain—as students learn to better write the critical features of letters, they also learn to recognize them more fluently. This recognition of letters leads to greater letter-writing fluency, which leads to greater overall reading development.<br>

- Introduction to MNIST

- EDA

- Normalization

- Baseline Model

- Model Evaluation

- First improved Model

- Second improved Model
