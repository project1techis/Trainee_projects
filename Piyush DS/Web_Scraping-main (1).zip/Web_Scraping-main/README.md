# Web_Scraping
# Scraping Top 100 Chess Players Details using Python<br>
In this project we are going scrape Top 100 Chess Players in the world by Rating category.<br>
Web Scraping is the process of extracting and parsing data from websites in an automated fashion using computer program<br>
* Importing requests library
* Downloading web pages using requests library
* Requests library allows you to access the HTTP links
