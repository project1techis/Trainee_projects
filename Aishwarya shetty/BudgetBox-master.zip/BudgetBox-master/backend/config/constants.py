TRANSACTION_TYPE = (
    ('income', 'Income'),
    ('expense', 'Expense'),
)
TRANSACTION_TYPE_DICT = dict(TRANSACTION_TYPE)