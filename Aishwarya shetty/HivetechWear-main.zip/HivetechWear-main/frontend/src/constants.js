export const Female = `Women's`;
export const Male = `Men's`;
