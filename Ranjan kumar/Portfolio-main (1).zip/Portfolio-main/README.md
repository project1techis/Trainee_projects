# Portfolio
This portfolio is a project using HTML CSS and Bootstrap. I will be using this to showcase my projetc!
[Live Heroku Deployement](https://portfolio-ranjan.herokuapp.com/)
![screenshiot](![<img width="1440" alt="Screenshot 2022-07-21 at 2 31 00 PM" src="https://user-images.githubusercontent.com/106957343/180175358-b580ecd4-9e56-47f0-b1bc-f999eb507273.png">
])



## Technologies used 
* HTML
* CSS

## Installation
No need to install any software, just open aindex.HTML

## How to use this to our?
use this tempelate to build your own portfolio.
