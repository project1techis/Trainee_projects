from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .models import Post
from .forms import PostForm



def index(request):
    posts=Post.objects.all().order_by('-created_at')[:20]
    if request.method=='POST':
        form=PostForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/')
        else:
            return HttpResponseRedirect(form.errors.as_json())

   
    return render(request,'posts.html',
    {'posts':posts})

def delete(request,post_id):
    post=Post.objects.get(id= post_id )
    post.delete()
    return HttpResponseRedirect('/')

def edit(request,post_id):
   post = Post.objects.get(id=post_id)
   if request.method == 'POST':
      form= PostForm(request.POST, request.FILES, instance=post)
      if form.is_valid():
         form.save()
         return HttpResponseRedirect('/')
      else:
         return HttpResponseRedirect(form.erros.as_json())
   return render(request, "edit.html",{"post" : post})

def likecount(request,post_id):
    like=Post.objects.get(id=post_id)
    like.likecount += 1
    like.save()
    return HttpResponseRedirect('/')

    

def unlikecount(request,post_id):
    unlike=Post.objects.get(id=post_id)
    unlike.unlikecount += 1
    unlike.save()
    return HttpResponseRedirect('/')

  



    
