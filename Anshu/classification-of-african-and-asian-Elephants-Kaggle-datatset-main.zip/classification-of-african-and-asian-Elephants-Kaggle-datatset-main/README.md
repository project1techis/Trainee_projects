# classification-of-african-and-asian-Elephants-Kaggle-datatset

In this Project, I am going to perform a Cnvolution Neural Network on a given dataset and will try to classify wheather the elephant in the image is Asian or African. But First lets import few required libraries

This dataset is created to practice various image classification techniques.

The image data is collected using google image search ( under "creative commons license" ).

# Dataset details

Number of classes: 2 (Asian elephant and African elephant )

Number of images: 1028

Image shape range: ( 100, 100) to (4992, 3328)

To increase complexity the train set contains less than 5% mislabeled images, while all images in the test set have the correct label.
